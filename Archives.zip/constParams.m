% Import SI units from an external database
load ./Database/siParams m s J g kg

% Speed of light in vacuum
c = 299792458 *m/s;

% Permeability of free space
mu0 = pi * 4e-7;

% Permittivity of free space
eps0 = 1/(c^2 * mu0);

% Avogadro's number
nAvog = 6.02214179e23;

% Atomic mass unit
amu = 1/nAvog *g;

% Electron's properties
qe = -1;                            % Unit charge of an electron
qp = 1;                             % Unit charge of a proton
qn = 0;                             % Unit charge of a neutron
me = 9.10938215e-31 *kg;            % Mass of an electron
re = 2.817940289e-15 *m;            % Radius of an electron
e = 1.602176487e-19 *qe;            % Electric charge of an electron

% Unit pressure
Torr = 1/760;

% Planck's constant
hbar = 1.054571800e-34 *J*s;
h = 2 * pi * hbar;

% Unit angle
deg = pi/180;

% Unit temperature
K = 1;

% Boltzmann's constant
kB = 1.38064852e-23;

% Remove SI units loaded from the external database
clear m s J g kg

% Store all constant parameters in an external database
save('./Database/constParams.mat', '-v6');

% Clear workspace
clear all %#ok<*CLALL>