function [] = simplot(X, Z, Y0, Y1, Y2)

    % Make figure
    figure(1)
    Y0 = abs(Y0).^2;
    Y1 = abs(Y1).^2;
    Y2 = abs(Y2).^2;

    % Visualize both Y1 and Y2 signals
    subplot(3,1,1)
    plot(X, Y1, 'b'); hold on
    plot(X, Y2, '.m'); grid on
    xlim([X(1) X(end)])
    pbaspect([1 1 1])

    % Visualize the absolute error between those signals
    subplot(3,1,2)
    epsmat = ones(length(Y1), 1) .* eps;
    semilogy(X, [abs(Y1 - Y2), epsmat]); grid on
    xlim([X(1) X(end)])
    pbaspect([1 1 1])

    % 3D Presentation
    if ~isempty(Y0)
        subplot(3,1,3)
        [Z2, X2] = meshgrid(Z, X);
        surface(Z2, X2, Y0)
        xlim([Z(1) Z(end)])
        ylim([X(1) X(end)])
        colormap gray
        shading interp
        pbaspect([1 1 1])
    end

    % Root mean square error
    rmse = mean((Y1 - Y2).^2)^0.5;
    fprintf('\nRMSE = %1.4E\n', rmse)

end