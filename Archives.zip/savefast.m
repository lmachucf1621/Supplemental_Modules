function savefast(filename, varargin)

    % Extract the variable values
    vars = cell(size(varargin));
    for i = 1 : numel(vars)
        vars{i} = evalin('caller', varargin{i});
    end

    % Separate numeric arrays from the rest
    isnum = cellfun(@(x) isa(x, 'numeric'), vars);
  
    % Append .mat if necessary
    [filepath, filebase, ext] = fileparts(filename);
    if isempty(ext)
        filename = fullfile(filepath, [filebase '.mat']);
    end

    % Save a dummy variable to create the file
    create_dummy = false;
    if all(isnum)
        dummy = 0;
        save(filename, '-v7.3', 'dummy');
        create_dummy = true;
    else
        s = struct;
        for i = 1 : numel(isnum)
            if ~isnum(i)
                s.(varargin{i}) = vars{i};
            end
        end
        save(filename, '-v7.3', '-struct', 's');
    end

    % Delete the dummy
    if create_dummy
        fid = H5F.open(filename, 'H5F_ACC_RDWR', 'H5P_DEFAULT');
        H5L.delete(fid, 'dummy', 'H5P_DEFAULT');
        H5F.close(fid);
    end
  
    % Save all numeric variables
    for i = 1 : numel(isnum)
        if ~isnum(i)
            continue
        end
        varname = ['/' varargin{i}];
        h5create(filename, varname, size(vars{i}), 'DataType', class(vars{i}));
        h5write(filename, varname, vars{i});
    end

end

