% Pre-script processing
clear all
close all
clc

% Size of solution matrices
nskip = 2^6;
nkeep = 2^8;
nr = 2^9;

% Initialization of solution matrices
x = zeros(nkeep, 1);
rmat = zeros(nkeep, nkeep);
xmat = zeros(nkeep, nkeep);

% Discretization of the parameter to be studied
rmin = 2.5;
rmax = 4;
dr = (rmax - rmin)/nr;
rstep = rmin + (0 : 1 : nr-1).' .* dr;

% Calculate the bifurcation diagram
tic                         % Start timing
for ir = 1 : 1 : nr
    x(1) = 0.5;
    for n = 1 : nskip
        x(1) = rstep(ir) * x(1) * (1 - x(1));
    end
    for n = 1 : nkeep-1
        x(n+1) = rstep(ir) * x(n) * (1 - x(n));
    end
    rmat(:, ir) = rstep(ir) .* ones(nkeep, 1);
    xmat(:, ir) = x;
end
toc                         % Stop timing

% Visualize the bifurcation diagram
figure(1)
plot(rmat(:), xmat(:), '.', 'markersize', 0.5);
title('Bifurcation diagram of the logistic map')
xlabel('r')
ylabel('x_n')
xlim([rmin rmax])
whitebg('black')