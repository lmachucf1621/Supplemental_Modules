% Unit time
s = 1;
ms = 1e-3 *s;
us = 1e-6 *s;
ns = 1e-9 *s;
ps = 1e-12 *s;
fs = 1e-15 *s;
as = 1e-18 *s;
zs = 1e-21 *s;

% Unit length
m = 1;
km = 1e3 *m;
cm = 1e-2 *m;
mm = 1e-3 *m;
um = 1e-6 *m;
nm = 1e-9 *m;
pm = 1e-12 *m;
ang = 1e-10 *m;

% Unit frequency
Hz = 1;
kHz = 1e3 *Hz;
MHz = 1e6 *Hz;
GHz = 1e9 *Hz;
THz = 1e12 *Hz;
PHz = 1e15 *Hz;

% Unit energy
J = 1;
mJ = 1e-3 *J;
uJ = 1e-6 *J;
nJ = 1e-9 *J;
pJ = 1e-12 *J;
kJ = 1e3 *J;
MJ = 1e6 *J;
GJ = 1e9 *J;
eV = 1.6e-19 *J;

% Unit power
W = 1;
mW = 1e-3 *W;
uW = 1e-6 *W;
nW = 1e-9 *W;
pW = 1e-12 *W;
kW = 1e3 *W;
MW = 1e6 *W;
GW = 1e9 *W;
TW = 1e12 *W;
EW = 1e15 *W;

% Unit mass
kg = 1;
g = 1e-3 *kg;

% Store all SI units in an external database
save('./Database/siParams.mat', '-v6');

% Clear workspace
clear all %#ok<*CLALL>