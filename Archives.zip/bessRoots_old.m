%{
    In this script, we compute N roots of nth-order Bessel function.
    The Halley's root finding algorithm is used. It is a variant of the
    Newton-Raphson method but quicker computationally.
%}

% Pre-script processing
clear all
close all
clc

%{
    Machine's precision is used as the deciding factor. This number, 'eps',
    varies across different computers. It indicates the maximum accuracy
    that can be achieved on a given computer.
%}

% Halley's parameters
niter = 20;                     % Number of iterations per solution
err = eps;                      % Machine's precision

% Bessel's parameters
nroots = 2^15;                  % Number of roots to be computed
bess0s = zeros(nroots, 1);      % Solution matrix

%{
    Typically, derivatives of a given function need to be computed
    numerically. However, since we've already known their analytical forms,
    it's more accurate and faster to use them instead.
%}

% Bessel's function and its 2nd- & 3rd-derivatives
f =@(z) besselj(0, z);
fp =@(z) -besselj(1, z);
fpp =@(z) 0.5 .* (-besselj(0, z) + besselj(2, z));

% Execute the Halley's algorithm
z0 = 1 + sqrt(2);
for i = 1 : 1 : nroots
    while true
        % Halley's formula
        z = z0 - (f(z0)/fp(z0)) * (1 - (f(z0) * fpp(z0)/fp(z0)^2))^-1;

        % Check the error tolerance
        if (abs(z - z0)/abs(z)) < err
            bess0s(i) = z;                  % Add root to the solution matrix
            z0 = 1 + sqrt(2) + i * pi;      % Advance the value of guess
            break
        else
            z0 = z;
        end
    end
end

% Store the solution matrix in an external database
save('./Database/bess0s_old.mat', 'bess0s', '-v6');