% Import constant parameters from an external database
load ./Database/constParams eps0 hbar me e c kB

% Unit of atomic interactions (High-field Physics)
eAU = 1;                                            % electron charge
meAU = 1;                                           % electron mass
eps0AU = (4 * pi)^-1;                               % permittivity of free space 
rAU = (4 * pi * eps0 * hbar^2)/(me * e^2);          % length
EAU = (me * e^4)/(4 * pi * eps0 * hbar)^2;          % energy/hartree
tAU = hbar/EAU;                                     % time
fAU = 1/tAU;                                        % frequency
muAU = e * rAU;                                     % electric dipole moment
muBAU = (e * hbar)/(2 * me);                        % magnetic dipole moment
efAU = EAU/muAU;                                    % electric field strength
bfAU = 0.5 * EAU/muBAU;                             % magnetic field strength
ifAU = 0.5 * eps0 * c * efAU^2;                     % high-field intensity
cAU = 4 * pi * eps0 * hbar * c/e^2;                 % speed of light
vAU = c/cAU;                                        % electron velocity per Bohr orbit
tempAU = EAU/kB;                                    % temperature

% Remove constant parameters loaded from the external database
clear eps0 hbar me e c kB

% Store all AU units in an external database
save('./Database/auParams.mat', '-v6');

% Clear workspace
clear all %#ok<*CLALL>