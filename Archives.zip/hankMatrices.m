% Pre-script processing
clear all
close all
clc

% Load pre-calculated roots of nth-order Bessel function
load ./Database/bess0s.mat bess0s;

% Set the size of each Hankel matrix of nth order
npts = 2^8;
ord = 0;

% Check for 'out of bounds' errors
[nroots, nord] = size(bess0s);
if ord > nord
    disp('Missing roots for the chosen nth-order Bessel function!')
    return
else
    if npts > nroots
        disp('Number of sampling points is greater than number of roots available!')
        return
    else
        hankmat = bess0s(1:npts+1, ord+1).';
    end
end

% Compute the Hankel matrix of nth order
S = hankmat(npts+1);
[Jn, Jm] = meshgrid(hankmat(1:npts), hankmat(1:npts));
denorm = abs(besselj(ord+1, Jn)) .* abs(besselj(ord+1, Jm)) .* S;
hankmat = 2 .* besselj(ord, Jn .* Jm./S)./denorm;

% Store the solution matrix in an external database
save(['./Database/hankmat', num2str(ord), '_', num2str(npts), '.mat'], 'hankmat', '-v6');